package com.rm.tikfollow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TikFollowApp() }
    }
}

private enum class Screen { HOME, TASKS, HISTORY, ACCOUNT }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TikFollowApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Add your Firebase config to enable account features.") }
    var signedIn by remember { mutableStateOf(false) }
    var coins by remember { mutableIntStateOf(0) }
    var isFirebaseReady by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        isFirebaseReady = try { FirebaseApp.getApps(context).isNotEmpty() } catch (_: Exception) { false }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF25F4EE),
        secondary = androidx.compose.ui.graphics.Color(0xFFFE2C55),
        background = androidx.compose.ui.graphics.Color(0xFF101014),
        surface = androidx.compose.ui.graphics.Color(0xFF1B1B22)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("TikFollow", fontWeight = FontWeight.Bold) },
                    actions = { Text("🪙 $coins", modifier = Modifier.padding(end = 16.dp), fontWeight = FontWeight.Bold) }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = screen == Screen.HOME, onClick = { screen = Screen.HOME }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = screen == Screen.TASKS, onClick = { screen = Screen.TASKS }, icon = { Icon(Icons.Default.CheckCircle, null) }, label = { Text("Tasks") })
                    NavigationBarItem(selected = screen == Screen.HISTORY, onClick = { screen = Screen.HISTORY }, icon = { Icon(Icons.Default.History, null) }, label = { Text("History") })
                    NavigationBarItem(selected = screen == Screen.ACCOUNT, onClick = { screen = Screen.ACCOUNT }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Account") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                when (screen) {
                    Screen.HOME -> {
                        Text("Welcome${if (signedIn) " back" else ""}!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Complete legitimate community tasks and track your points.")
                        Card {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Your balance", style = MaterialTheme.typography.titleMedium)
                                Text("$coins coins", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                                Text("Points are a demo until Firebase and server-side validation are configured.")
                            }
                        }
                        Button(onClick = { screen = Screen.TASKS }, modifier = Modifier.fillMaxWidth()) { Text("Browse tasks") }
                        Text("Safety: no TikTok password collection, automated follows, or guaranteed engagement.")
                    }
                    Screen.TASKS -> {
                        Text("Community tasks", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Demo task list. Task completion and rewards must be verified server-side before coins are credited.")
                        listOf("Open a public TikTok profile", "Watch a public creator video", "Share your own profile link").forEachIndexed { index, task ->
                            Card {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(task, fontWeight = FontWeight.SemiBold)
                                        Text("Review required • no automatic follow")
                                    }
                                    Text("+${(index + 1) * 5} coins")
                                }
                            }
                        }
                    }
                    Screen.HISTORY -> {
                        Text("History", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("No verified transactions yet.")
                        Card { Text("When Firebase is configured, show server-verified coin and task events here.", Modifier.padding(16.dp)) }
                    }
                    Screen.ACCOUNT -> {
                        Text("Account", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Firebase Authentication setup")
                        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = {
                            if (!isFirebaseReady) {
                                status = "Firebase is not configured. Add app/google-services.json and enable Email/Password in Firebase Console."
                            } else if (email.isBlank() || password.length < 6) {
                                status = "Enter a valid email and a password of at least 6 characters."
                            } else {
                                val auth = FirebaseAuth.getInstance()
                                auth.createUserWithEmailAndPassword(email.trim(), password)
                                    .addOnSuccessListener {
                                        signedIn = true
                                        status = "Account created. Configure Firestore rules before storing user data."
                                    }
                                    .addOnFailureListener { e -> status = e.localizedMessage ?: "Authentication failed." }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Register") }
                        OutlinedButton(onClick = {
                            if (!isFirebaseReady) status = "Add app/google-services.json first."
                            else FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(), password)
                                .addOnSuccessListener { signedIn = true; status = "Signed in." }
                                .addOnFailureListener { e -> status = e.localizedMessage ?: "Sign-in failed." }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Login") }
                        Text(status, color = MaterialTheme.colorScheme.secondary)
                        Text("Admin access is not granted by this screen. Use a trusted backend to assign admin roles.")
                    }
                }
            }
        }
    }
}
