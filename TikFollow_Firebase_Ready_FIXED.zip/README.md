# TikFollow — Android starter

A starter Android app inspired by the general task/points layout of TopFollow. It is **not** a copy of TopFollow and does not automate TikTok engagement.

## What's included
- Kotlin + Jetpack Compose Android UI
- Home, Tasks, History, Account screens
- Firebase Authentication email/password hooks
- Firebase Firestore dependency and conservative starter rules
- GitHub Actions workflow to build and upload a debug APK artifact

## Build an APK from your phone using GitHub
1. Create a new public or private GitHub repository named `TikFollow`.
2. Upload the **contents** of this ZIP to the repository root (not the ZIP itself).
3. Open **Actions** → **Build TikFollow APK** → **Run workflow**.
4. Open the completed run and download `TikFollow-debug-apk` from **Artifacts**.
5. Extract the artifact ZIP to get `app-debug.apk`.

## Enable Firebase

The uploaded Firebase configuration is included at `app/google-services.json` and the app package name is set to `com.rm.tikfollow` to match it.
1. In Firebase Console, create an Android app with package name `com.rm.tikfollow`.
2. Download `google-services.json` and upload it to `app/google-services.json`.
3. In Firebase Authentication, enable **Email/Password**.
4. Create a Firestore database and review `firestore.rules` before publishing.
5. Push the changes and run the workflow again.

Without `google-services.json`, the app should still build, but Firebase login reports that configuration is missing.

## Important security and policy notes
- The Tasks, coin balance, and History screens are a UI scaffold; they do not award real points.
- Do not trust coin balances or task completion submitted by the Android client. Add a trusted backend (e.g. Cloud Functions) to verify tasks and write transactions.
- Never collect TikTok passwords or session cookies.
- Do not automate follows, likes, views, or other fake engagement. Use official TikTok links and permitted user-initiated actions.
- Admin access must be assigned by a trusted backend/custom claims, never by a user-editable Firestore field.
- Before release, add privacy policy, account deletion, abuse reporting, rate limits, and proper Firestore rules.
