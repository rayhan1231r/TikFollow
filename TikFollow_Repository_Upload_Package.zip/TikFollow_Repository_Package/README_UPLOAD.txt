TikFollow GitHub upload package

Contents:
- TikFollow_Firebase_Ready.zip: Android project source ZIP.
- .github/workflows/build.yml: workflow that extracts the project ZIP, builds a debug APK, and uploads the APK artifact.

IMPORTANT:
Uploading this outer ZIP as one file to GitHub does NOT automatically extract its contents into the repository. GitHub Actions only detects a workflow when the YAML file itself is committed at .github/workflows/build.yml.

On GitHub mobile/browser:
1. Open https://github.com/rayhan1231r/TikFollow
2. Add/Upload the project ZIP as a repository-root file named exactly TikFollow_Firebase_Ready.zip.
3. Create the workflow file at .github/workflows/build.yml and paste the contents of the build.yml supplied in this package.
4. Open Actions > Build TikFollow APK from ZIP > Run workflow (or upload/commit the ZIP after workflow exists).
5. When it succeeds, open the run and download the TikFollow-debug-apk artifact ZIP. Extract it to get app-debug.apk.

The GitHub connector could read repository metadata but GitHub rejected the direct write request (403 Resource not accessible by integration), so no workflow file has been committed by the assistant. APK build is not yet verified.
